const express = require('express')
const app = express()
const bodyParser = require("body-parser");
const { time } = require('console');
const http = require("http").Server(app); 
const io = require("socket.io")(http);
const tid = new Date()
const timme = tid.getHours() +":" + tid.getMinutes();
console.log(timme)




app.use(express.static("./webbsidan"));
app.use(bodyParser.urlencoded({extended: false}));


let messages = []
let tider = []

app.get("/tider", (req, res) =>{
  res.send(tider);
})

app.post("/tider", (req,res) =>{
  tider.push(req.body);
  io.emit("tid", req.body);
})

app.get("/meddelanden", (req, res) => {
  res.send(messages);
})

app.post("/meddelanden", (req, res) => {
  messages.push(req.body);
  io.emit("message", req.body);
  res.sendStatus(200)
})

io.on("connection", (socket) => {
  console.log("En användare anslöt sig");
})


http.listen(3000, () => {
  console.log("servern körs, besök http://localhost:3000");

});

